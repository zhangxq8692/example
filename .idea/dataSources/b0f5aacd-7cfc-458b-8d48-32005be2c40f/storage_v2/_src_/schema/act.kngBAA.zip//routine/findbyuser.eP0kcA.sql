create procedure findByUser(IN account VARCHAR(12), IN password VARCHAR(12), OUT succeed INT(10))
  BEGIN
    declare psd varchar(12);
    select password from user where account = account into psd;
    if psd = password
    then
      set succeed = 5;
    else
      set succeed = 2;
    end if;
  END;

