create function hello()
  returns varchar(255) CHARSET utf8
  BEGIN
            RETURN 'Hello ， 我是MySql的自定义无参函数--hello';
END;

